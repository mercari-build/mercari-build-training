#!/bin/bash

set -e

go vet ./...
